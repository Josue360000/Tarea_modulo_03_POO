package com.mycompany.tareamodulo3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class libro {

private String titulo;
private String autor;
private int aniopublicacion;
private String genero;
private boolean disponible;
private int calificacion;
private String comentario;

public libro(String titulo, String autor, int aniopublicacion, String genero) {
this.titulo = titulo;
this.autor = autor;
this.aniopublicacion = aniopublicacion;
this.genero = genero;
this.disponible = true;
this.calificacion = 1;
this.comentario = "sin comentario";
}

public String conseguirtitulo() {
return titulo;
}
public String conseguirautor() {
return autor;
}
public int conseguiraniopublicacion() {
return aniopublicacion;
}
public String conseguirgenero() {
return genero;
}
public boolean estadisponible() {
return disponible;
}
public void prestar() {
this.disponible = false;
}
public void devolver() {
this.disponible = true;
}
public int conseguircalificacion() {
return calificacion;
}
public void calificar(int aclasificarlibro) {
this.calificacion = aclasificarlibro;
}
public String comentario() {
return comentario;
}
public void comentar(String acomentarlibro) {
this.comentario = acomentarlibro;
}



public String toString() {
return "Titulo: " + titulo + ", Autor: " + autor + ", Anio: " + aniopublicacion + ", Genero: " + genero + ", Calificacion: " + calificacion + ", Comentario: " + comentario + ", Disponible: " + (disponible ? "Si" : "No");
}
}

class biblioteca {
private List<libro> libros;

public biblioteca() {
libros = new ArrayList<>();
}

public void agregarlibro(libro libro) {
libros.add(libro);
System.out.println("\nLibro agregado: " + libro.conseguirtitulo());
}

public void buscarportitulo(String titulo) {
for (libro libro : libros) {
if (libro.conseguirtitulo().equalsIgnoreCase(titulo)) {
System.out.println(libro);
}
}
}

public void buscarporautor(String autor) {
for (libro libro : libros) {
if (libro.conseguirautor().equalsIgnoreCase(autor)) {
System.out.println(libro);
}
}
}

public void prestarlibro(String titulo) {
for (libro libro : libros) {
if (libro.conseguirtitulo().equalsIgnoreCase(titulo) && libro.estadisponible()) {
libro.prestar();
System.out.println("\nLibro prestado: " + titulo);
return;
}
}
System.out.println("\nEl libro '" + titulo + "' no esta disponible, fue prestado");
}

public void devolverlibro(String titulo) {
for (libro libro : libros) {
if (libro.conseguirtitulo().equalsIgnoreCase(titulo) && !libro.estadisponible()) {
libro.devolver();
System.out.println("\nLibro devuelto: " + titulo);
return;
}
}
System.out.println("\nEl libro '" + titulo + "' esta disponible, no fue prestado");
}

public void mostrarlibrosdisponibles() {
System.out.println("\nLibros disponibles:");
for (libro libro : libros) {
if (libro.estadisponible()) {
System.out.println("\n--------------------------------------------------------------------------------------------------");  
System.out.println(libro);
}
}
}


public void calificarlibro(String titulo, int calificacionlibro) {
for (libro libro : libros) {
if (libro.conseguirtitulo().equalsIgnoreCase(titulo) && calificacionlibro > 0 && calificacionlibro < 11) {
libro.calificar(calificacionlibro);
System.out.println("\nLibro " + titulo + " calificado con un puntaje de: " + calificacionlibro);
return;
}
}
System.out.println("\nLa operacion no es valida");
}


public void comentarlibro(String titulo, String comentariolibro) {
for (libro libro : libros) {
if (libro.conseguirtitulo().equalsIgnoreCase(titulo)) {
libro.comentar(comentariolibro);
System.out.println("\nSe ha insertado un comentario en el libro  " + titulo);
return;
}
}
System.out.println("\nLa operacion no es valida");
}


public void estadistica(int comedia, int romance, int fantasia, int ciencia, int historia, int noreconocido) {
int cantcomedia = comedia;
int cantromance = romance;
int cantfantasia = fantasia;
int cantciencia = ciencia;
int canthistoria = historia;
int cantnoreconocido = noreconocido;  
    
for (libro libro : libros) {
if (libro.conseguirgenero().equalsIgnoreCase("Comedia")) {
cantcomedia = cantcomedia + 1;
}
if (libro.conseguirgenero().equalsIgnoreCase("Romance")) {
cantromance = cantromance + 1;
}
if (libro.conseguirgenero().equalsIgnoreCase("Fantasia")) {
cantfantasia = cantfantasia + 1;
}
if (libro.conseguirgenero().equalsIgnoreCase("Ciencia")) {
cantciencia = cantciencia + 1;
}
if (libro.conseguirgenero().equalsIgnoreCase("Historia")) {
canthistoria = canthistoria + 1;
}
if (libro.conseguirgenero().equalsIgnoreCase("Genero no reconocido")) {
cantnoreconocido = cantnoreconocido + 1;
}
}
System.out.print("\nEstadistica de generos de los libros: ");  
System.out.print("\nComedia: " + cantcomedia);
System.out.print("\nRomance: " + cantromance);
System.out.print("\nFantasia: " + cantfantasia);
System.out.print("\nCiencia: " + cantciencia);
System.out.print("\nHistoria: " + canthistoria);
System.out.print("\nGenero no reconocido: " + cantnoreconocido);
}

}


public class Tareamodulo3 {
public static void main(String[] args) {
   
biblioteca biblioteca = new biblioteca();
Scanner scanner = new Scanner(System.in);
boolean continuar = true;
String genero = "Genero no reconocido";


while (continuar) {
System.out.println("---------------------------------------------------------------------------------------------");
System.out.println("\n\nMenu de la Biblioteca:");
System.out.println("\n1. Agregar libro");
System.out.println("2. Buscar libro por titulo");
System.out.println("3. Buscar libro por autor");
System.out.println("4. Prestar libro");
System.out.println("5. Devolver libro");
System.out.println("6. Calificar libro");
System.out.println("7. Comentar libro");
System.out.println("8. Mostrar libros disponibles");
System.out.println("9. Mostrar generos de libros mas frecuentes");
System.out.println("10. Salir del programa");
System.out.print("Seleccione una opcion: ");
int opcion = scanner.nextInt();
scanner.nextLine(); 

switch (opcion) {
    
case 1:
System.out.print("\nIngrese el titulo del libro: ");
String titulo = scanner.nextLine();
System.out.print("\nIngrese el autor del libro: ");
String autor = scanner.nextLine();
System.out.print("\nIngrese el anio de publicacion: ");
int anio = scanner.nextInt();
scanner.nextLine();
System.out.print("\nIngrese el genero del libro [1: Comedia, 2: Romance, 3: Fantasia, 4: Ciencia, 5: Historia]: ");
int numgenero = scanner.nextInt();

switch (numgenero) {
case 1:
genero = "Comedia";
break;

case 2:
genero = "Romance";
break;
           
case 3:
genero = "Fantasia";
break;
            
case 4:
genero = "Ciencia";
break;
            
case 5:
genero = "Historia";
break;  

default:
genero = "Genero no reconocido";
break;
}

biblioteca.agregarlibro(new libro(titulo, autor, anio, genero));
break;

case 2:
System.out.print("\nIngrese el titulo a buscar: ");
String tituloBuscar = scanner.nextLine();
biblioteca.buscarportitulo(tituloBuscar);
break;

case 3:
System.out.print("\nIngrese el autor a buscar: ");
String autorBuscar = scanner.nextLine();
biblioteca.buscarporautor(autorBuscar);
break;

case 4:
System.out.print("\nIngrese el titulo del libro a prestar: ");
String tituloPrestar = scanner.nextLine();
biblioteca.prestarlibro(tituloPrestar);
break;

case 5:
System.out.print("\nIngrese el titulo del libro a devolver: ");
String tituloDevolver = scanner.nextLine();
biblioteca.devolverlibro(tituloDevolver);
break;

case 6:
System.out.print("\nIngrese el titulo del libro a calificar: ");
String titulocalificar = scanner.nextLine();
System.out.print("Ingrese la calificacion del libro del 1 al 10: ");
int calificacionlibro = scanner.nextInt();
biblioteca.calificarlibro(titulocalificar, calificacionlibro);
break;

case 7:
System.out.print("\nIngrese el titulo del libro a comentar: ");
String titulocomentar = scanner.nextLine();
System.out.print("Ingrese el comentario: ");
String comentariolibro = scanner.nextLine();
biblioteca.comentarlibro(titulocomentar, comentariolibro);
break;

case 8:
System.out.print("");
biblioteca.mostrarlibrosdisponibles();
break;

case 9:
biblioteca.estadistica(0,0,0,0,0,0);
break;

case 10:
continuar = false;
break;
default:
System.out.println("\nOperacion no valida");
}
}
scanner.close();
}
}


